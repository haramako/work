package shogi

import (
	"testing"
)

func TestHoge(t *testing.T) {
}